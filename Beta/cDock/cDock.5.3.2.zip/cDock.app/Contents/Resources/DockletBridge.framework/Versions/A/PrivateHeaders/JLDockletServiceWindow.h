//
//  JLDockletServiceWindow.h
//  DockletService
//
//  Created by Jeremy on 5/14/21.
//  Copyright © 2021 Jeremy Legendre. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <IOSurface/IOSurfaceObjC.h>
#import "JLDockletServiceViewController.h"

NS_ASSUME_NONNULL_BEGIN

@protocol JLDockletServiceWindowProtocol <NSObject>
- (void)hostFrameWillChange:(NSValue*)frameVal;
- (void)helperContextID:(void (^)(NSNumber*))reply;
- (void)setDockletSize:(NSNumber*)dockletSize;
- (void)willBeRemovedFromDock;
- (void)serviceWindowID:(void (^)(NSNumber*))reply;
- (void)serviceWindowAndContextIDs:(void(^)(NSNumber *windowID, NSNumber *layerContextID))reply;
- (void)screenShot:(void (^)(NSData*))reply;
- (void)screenShot2:(void (^)(IOSurface*))reply;
@end

@protocol JLDockletHostProtocol <NSObject>
- (void)getCurrentDockletSize:(void (^)(NSNumber*))reply;
- (void)serviceWindowReceivedEvent:(NSData *)eventData;
@end

@interface JLDockletServiceWindow : NSPanel <NSWindowDelegate, JLDockletServiceWindowProtocol>
@property (retain) id<JLDockletHostProtocol> hostProxy;
@property (nullable, strong) JLDockletServiceViewController *contentViewController;
- (void)hostFrameWillChange:(NSValue*)frameVal;
- (void)helperContextID:(void (^)(NSNumber*))reply;
- (void)setDockletSize:(NSNumber*)dockletSize;
- (void)willBeRemovedFromDock;
- (void)serviceWindowAndContextIDs:(void(^)(NSNumber *windowID, NSNumber *layerContextID))reply;

+ (instancetype)windowWithContentViewController:(JLDockletServiceViewController *)contentViewController;
@end

NS_ASSUME_NONNULL_END
