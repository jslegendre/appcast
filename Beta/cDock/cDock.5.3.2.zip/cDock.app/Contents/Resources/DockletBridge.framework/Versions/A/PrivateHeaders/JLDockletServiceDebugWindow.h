//
//  JLDockletServiceDebugWindow.h
//  DockletBridge
//
//  Created by Jeremy on 6/5/21.
//  Copyright © 2021 Jeremy Legendre. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "JLDockletServiceViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface JLDockletServiceDebugWindow : NSPanel
@property (nullable, strong) JLDockletServiceViewController *contentViewController;
- (void)setDockletSize:(JLDockletTileSize)dockletSize;
+ (instancetype)windowWithContentViewController:(JLDockletServiceViewController *)contentViewController;
@end

NS_ASSUME_NONNULL_END
