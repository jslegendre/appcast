//
//  DockletServiceAppDelegate.h
//  DockletBridge
//
//  Created by Jeremy on 6/5/21.
//  Copyright © 2021 Jeremy Legendre. All rights reserved.
//

#import <AppKit/AppKit.h>
#import "AppKitSPI.h"

NS_ASSUME_NONNULL_BEGIN

@interface DockletServiceAppDelegate : NSObject <NSApplicationDelegate, NSApplicationEventDelegate, NSXPCListenerDelegate>
@end

NS_ASSUME_NONNULL_END
