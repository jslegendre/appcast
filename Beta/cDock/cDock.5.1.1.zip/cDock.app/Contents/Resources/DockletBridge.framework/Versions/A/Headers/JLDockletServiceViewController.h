//
//  JLDockletServiceViewController.h
//  DockletService
//
//  Created by Jeremy on 5/15/21.
//  Copyright © 2021 Jeremy Legendre. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum {
    JLDockletTileSizeSmall = 1,
    JLDockletTileSizeMedium,
    JLDockletTileSizeLarge,
} JLDockletTileSize;

@interface JLDockletServiceViewController : NSViewController
@property JLDockletTileSize tileSize;
- (void)hostViewWillResizeTo:(CGSize)size;
- (void)willBeRemovedFromDock;
@end

NS_ASSUME_NONNULL_END
