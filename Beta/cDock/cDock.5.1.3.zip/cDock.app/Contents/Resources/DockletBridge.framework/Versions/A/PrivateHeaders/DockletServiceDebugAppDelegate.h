//
//  DockletServiceDebugAppDelegate.h
//  DockletBridge
//
//  Created by Jeremy on 6/5/21.
//  Copyright © 2021 Jeremy Legendre. All rights reserved.
//

#import <AppKit/AppKit.h>
#import "JLDockletServiceDebugWindow.h"

NS_ASSUME_NONNULL_BEGIN

@interface DockletServiceDebugAppDelegate : NSObject <NSApplicationDelegate, NSWindowDelegate>
@property (strong) JLDockletServiceDebugWindow *window;
@end

NS_ASSUME_NONNULL_END
