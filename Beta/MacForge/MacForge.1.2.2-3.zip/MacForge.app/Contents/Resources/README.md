## [Developer 👨‍💻](https://github.com/w0lfschild/MacForge/wiki/Bundles-:-Creating)

- [Contributing Code 🤝](https://github.com/w0lfschild/MacForge/blob/master/CONTRIBUTING.md)
- [Help wanted 💵](https://github.com/w0lfschild/MacForge/issues/16)
- [Submitting Issues 🐞](https://github.com/w0lfschild/MacForge/issues/new/choose)
- [Creating a bundle 🏗](https://github.com/w0lfschild/MacForge/wiki/Bundles-:-Creating)
- [Publishing a bundle 🛳](https://github.com/w0lfschild/MacForge/wiki/Bundles-:-Publishing)
- [Sharing a bundle 🔗](https://github.com/w0lfschild/MacForge/wiki/Bundles-:-Linking)
- [Selling a bundle 💰](https://github.com/w0lfschild/MacForge/wiki/Bundles-:-Selling)

## Troubleshooting 🐛

- Having problems? Submit an issue here: [submit](https://github.com/w0lfschild/MacForge/issues/new/choose)
