### Resources

- Icon : [Davi Andrade](http://www.daviandrade.com/)
- Analytics : [appcenter-sdk-apple](https://www.github.com/microsoft/appcenter-sdk-apple)
- Sales & Licenses : [Paddle](https://paddle.com/)
- Updates : [Sparkle](https://www.github.com/sparkle-project/Sparkle)
- LetsMove : [LetsMove](https://www.github.com/potionfactory/LetsMove)
- Folder monitoring : [MHWDirectoryWatcher](https://github.com/hwaxxer/MHWDirectoryWatcher)


### Developerment

- MacEnhance ([GitHub](https://github.com/MacEnhance)) ([Website](https://www.macenhance.com/))
- Wolfgang Baird ([GitHub](https://github.com/w0lfschild))
- Jeremy Legendre ([GitHub](https://github.com/jslegendre))
